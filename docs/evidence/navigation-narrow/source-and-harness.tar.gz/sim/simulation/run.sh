#!/usr/bin/env bash
set -euo pipefail
sim_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
sim_image="${DUOJIN_SIM_IMAGE:-duojin02:sim-humble-harmonic}"
sim_container="${DUOJIN_SIM_CONTAINER:-duojin02-sim-lab}"
sim_mode="${1:---headless}"
if [[ "$sim_mode" == --build ]]; then
  sim_base="${DUOJIN_SIM_BASE_IMAGE:-ros:humble-ros-base-jammy}"
  if [[ -z "${DUOJIN_SIM_BASE_IMAGE:-}" ]] && docker image inspect duojin01:humble-harmonic >/dev/null 2>&1; then
    sim_base=duojin01:humble-harmonic
  fi
  exec docker build -f "$sim_root/simulation/Dockerfile" --build-arg "SIM_BASE_IMAGE=$sim_base" -t "$sim_image" "$sim_root"
fi
[[ "$sim_mode" == --headless || "$sim_mode" == --gui ]] || { echo 'Usage: simulation/run.sh --build|--headless|--gui [launch arguments]'; exit 2; }
[[ $# == 0 ]] || shift
args=(--rm --init --name "$sim_container" --shm-size=1g --gpus all
  -e NVIDIA_DRIVER_CAPABILITIES=graphics,display,utility,compute
  -e "ROS_DOMAIN_ID=${DUOJIN_SIM_DOMAIN:-72}" -e "GZ_PARTITION=${DUOJIN_SIM_PARTITION:-duojin02_lab}"
  -v "$sim_root:/ws:ro" -w /tmp/duojin02_sim)
if [[ "$sim_mode" == --gui ]]; then
  [[ -n "${DISPLAY:-}" ]] || { echo 'GUI requires X11/XWayland DISPLAY; headless uses GPU EGL.'; exit 1; }
  args+=(-e "DISPLAY=$DISPLAY" -e QT_X11_NO_MITSHM=1 -v /tmp/.X11-unix:/tmp/.X11-unix:ro)
  if [[ -f "${XAUTHORITY:-}" ]]; then
    args+=(-v "$XAUTHORITY:/tmp/sim.xauth:ro" -e XAUTHORITY=/tmp/sim.xauth)
  fi
  exec docker run "${args[@]}" "$sim_image" headless:=false "$@"
fi
exec docker run "${args[@]}" "$sim_image" headless:=true "$@"
