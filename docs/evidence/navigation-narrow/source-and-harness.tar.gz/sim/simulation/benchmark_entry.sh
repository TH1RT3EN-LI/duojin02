#!/usr/bin/env bash
set -eo pipefail
source /opt/ros/humble/setup.bash
source /opt/duojin01/slam_backend/setup.bash
mkdir -p /tmp/navbuild /evidence
cd /tmp/navbuild
colcon build --base-paths /hardware/src/duojin01_navigation /hardware/src/duojin01_bringup \
  /hardware/src/duojin01_description /ws/simulation/src --cmake-args -DCMAKE_BUILD_TYPE=Release
source install/setup.bash
python3 /ws/simulation/record_navigation_build.py
exec python3 /ws/simulation/nav_benchmark_suite.py --output /evidence/final "$@"
