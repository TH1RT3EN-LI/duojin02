#!/usr/bin/env python3
"""Render measured slot dimensions and actual pillar interception evidence."""
import json
import math
from pathlib import Path
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import numpy as np

folder=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent/'evidence'
layer=json.loads((Path(__file__).resolve().parent/'evidence/lidar-layer.json').read_text())
scan=json.loads((folder/'scan_snapshot.json').read_text())
proof=json.loads((folder/'pillar-validation.json').read_text())
c,s=math.cos(scan['yaw']),math.sin(scan['yaw'])
origin=(np.array(scan['laser_world_xy'])-scan['base_world_xy'])@np.array([[c,-s],[s,c]])
fig,(side,top)=plt.subplots(1,2,figsize=(12,5.4),gridspec_kw={'width_ratios':[.8,1.2]})
bottom,upper=layer['slot_bottom_m']*1000,layer['slot_top_m']*1000
side.add_patch(Rectangle((0,112.308),1,bottom-112.308,facecolor='#64748b',alpha=.8))
side.add_patch(Rectangle((0,upper),1,4,facecolor='#64748b',alpha=.8))
side.axhline(layer['old_scan_height_m']*1000,color='#de6149',ls='--',label='Previous plane: 130.233 mm')
side.axhline(layer['candidate_scan_height_m']*1000,color='#1476c6',lw=2,label='Slot midpoint: 143.308 mm')
side.annotate('',xy=(.87,bottom),xytext=(.87,upper),arrowprops=dict(arrowstyle='<->',color='#374151'))
side.text(.84,(bottom+upper)/2,'22 mm',ha='right',va='center',fontsize=11)
side.text(.08,bottom-5,'Lower shell',color='white')
side.text(.08,upper+1.1,'Upper plate',color='white')
side.set(xlim=(0,1),ylim=(108,162),ylabel='Height above chassis datum (mm)',title='Measured CAD aperture')
side.set_xticks([]);side.grid(axis='y',alpha=.15);side.legend(loc='lower left',fontsize=8)
raw=np.array([np.nan if v is None else v for v in scan['raw_ranges']])
filtered=np.array([np.nan if v is None else v for v in scan['ranges']])
angles=scan['angle_min']+np.arange(len(raw))*scan['angle_increment']
blocked=np.isfinite(raw)&np.isnan(filtered)
hit=origin+np.column_stack((raw*np.cos(angles),raw*np.sin(angles)))
colors=plt.get_cmap('tab10')
for i,p in enumerate(layer['pillars']):
    for path in p['section_xy_m']:
        points=np.array(path)
        top.plot(points[:,0]*1000,points[:,1]*1000,color=colors(i),lw=1.5)
    center=np.mean(p['bounds_m'],axis=0)[:2]
    top.text(*(center*1000),str(i+1),ha='center',va='center',weight='bold',color=colors(i))
for p in proof['pillars']:
    for index in p['predicted_blocked_bins'][::2]:
        far=origin+.46*np.array([np.cos(angles[index]),np.sin(angles[index])])
        top.plot([origin[0]*1000,hit[index,0]*1000],[origin[1]*1000,hit[index,1]*1000],color='#f59e0b',alpha=.4,lw=.8)
        top.plot([hit[index,0]*1000,far[0]*1000],[hit[index,1]*1000,far[1]*1000],color='#e8594d',alpha=.18,lw=.8,ls='--')
top.scatter(hit[blocked,0]*1000,hit[blocked,1]*1000,s=16,color='#f59e0b',label='Actual near hits (raw scan)',zorder=5)
top.scatter(*(origin*1000),s=35,color='#1476c6',label='Laser origin',zorder=6)
top.plot([],[],color='#e8594d',ls='--',label='Occluded directions: no far return')
top.set(xlim=(-290,290),ylim=(-260,260),xlabel='Chassis X (mm)',ylabel='Chassis Y (mm)',
        title='6 native pillars; 54 blocked lidar bins')
top.set_aspect('equal');top.grid(alpha=.15);top.legend(loc='lower left',fontsize=8)
fig.suptitle('Reserved lidar layer: geometry and actual GPU returns',fontsize=14)
fig.tight_layout();fig.savefig(folder/'lidar-layer-inspection.png',dpi=170)
