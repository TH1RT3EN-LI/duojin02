#!/usr/bin/env python3
"""Run inside the live sim container. Validate geometry, devices, TF and motion."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics
import struct
import time
from collections import Counter
import numpy as np
from PIL import Image as PILImage
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, DurabilityPolicy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan, PointCloud2, Image, Imu, JointState, CameraInfo
from rosgraph_msgs.msg import Clock
from std_msgs.msg import Int8
from tf2_msgs.msg import TFMessage


def seconds(stamp):
    return stamp.sec + stamp.nanosec*1e-9


def yaw(q):
    return math.atan2(2*(q.w*q.z+q.x*q.y), 1-2*(q.y*q.y+q.z*q.z))


class Probe(Node):
    def __init__(self):
        super().__init__('sim_acceptance')
        self.latest, self.count, self.scans, self.tf = {}, Counter(), [], {}
        self.subs = []
        for key, topic, kind in [('clock', '/clock', Clock), ('scan', '/scan', LaserScan),
                                  ('raw_scan', '/sim/lidar/raw', LaserScan),
                                  ('cloud', '/lslidar_point_cloud', PointCloud2),
                                  ('odom', '/odom', Odometry), ('ekf', '/odometry/filtered', Odometry),
                                  ('imu', '/imu', Imu), ('joints', '/joint_states', JointState),
                                  ('overview', '/sim/overview/image', Image)]:
            self.subs.append(self.create_subscription(kind, topic, lambda msg, k=key:self.receive(k,msg), 10))
        for name in ('head', 'left', 'right'):
            prefix = '/dual_arm/' + name + '_camera_link/'
            self.subs.append(self.create_subscription(Image, prefix+'image', lambda msg, k=name:self.receive(k,msg), 10))
            self.subs.append(self.create_subscription(CameraInfo, prefix+'camera_info', lambda msg, k=name+'_info':self.receive(k,msg), 10))
        self.subs.append(self.create_subscription(TFMessage, '/tf', self.transforms, 100))
        self.subs.append(self.create_subscription(TFMessage, '/tf_static', self.transforms,
                          QoSProfile(depth=100, durability=DurabilityPolicy.TRANSIENT_LOCAL)))
        self.cmd = self.create_publisher(Twist, '/cmd_vel', 10)
        self.motor = self.create_publisher(Int8, '/motor_control', 1)

    def receive(self, key, msg):
        self.latest[key], self.count[key] = msg, self.count[key]+1
        if key == 'scan':
            self.scans.append(seconds(msg.header.stamp))

    def transforms(self, msg):
        for transform in msg.transforms:
            self.tf[transform.child_frame_id] = transform

    def wait(self, condition, timeout=40):
        end = time.monotonic()+timeout
        while time.monotonic() < end:
            rclpy.spin_once(self, timeout_sec=0.01)
            if condition():
                return
        raise AssertionError('Timed out: topics=' + str(list(self.latest)))

    @property
    def sim_time(self):
        return seconds(self.latest['clock'].clock)

    def advance(self, duration, command=None, continuous=True):
        start = self.sim_time
        last = 0
        def step():
            nonlocal last
            if command is not None and (continuous or last == 0) and time.monotonic()-last > 0.03:
                self.cmd.publish(command)
                last = time.monotonic()
            return self.sim_time >= start + duration
        self.wait(step, timeout=max(30, duration*40))


def expected_wall(angle, x, y):
    dx, dy = math.cos(angle), math.sin(angle)
    candidates = []
    if abs(dx) > 1e-8:
        candidates.append(((3 if dx>0 else -3)-x)/dx)
    if abs(dy) > 1e-8:
        candidates.append(((2.5 if dy>0 else -2.5)-y)/dy)
    return min(v for v in candidates if v > 0)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default='/tmp/acceptance')
    parser.add_argument('--benchmark-only', action='store_true')
    parser.add_argument('--seconds', type=float, default=10.0)
    parser.add_argument('--noise', action='store_true')
    args = parser.parse_args()
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    rclpy.init()
    node = Probe()
    report = {'status':'running', 'base_mode':'kinematic', 'noise':args.noise}
    try:
        from ament_index_python.packages import get_package_share_directory
        assets = Path(get_package_share_directory('duojin01_description'))/'models/dual_arm_mobile'
        metadata = json.loads((assets/'asset_manifest.json').read_text())
        report['installed_assets'] = {k:metadata[k] for k in ('quality_profile','visual_triangles','source_archive_sha256')}
        report['installed_assets']['mesh_count'] = len(list((assets/'meshes').glob('*.dae')))
        report['installed_assets']['model_sdf_sha256'] = hashlib.sha256((assets/'model.sdf').read_bytes()).hexdigest()
        required = {'clock','scan','raw_scan','cloud','odom','ekf','imu','joints','overview','head','left','right',
                    'head_info','left_info','right_info'}
        node.wait(lambda: required <= node.latest.keys())
        node.advance(0.5 if args.benchmark_only else 3)
        wall_start, sim_start, counts = time.monotonic(), node.sim_time, node.count.copy()
        node.advance(args.seconds)
        elapsed_sim, elapsed_wall = node.sim_time-sim_start, time.monotonic()-wall_start
        report['performance'] = dict(sim_seconds=elapsed_sim, wall_seconds=elapsed_wall,
            real_time_factor=elapsed_sim/elapsed_wall,
            topic_hz_sim={key:(value-counts[key])/elapsed_sim for key,value in node.count.items()})
        if args.benchmark_only:
            report['status']='passed'
            return
        scan = node.latest['scan']
        assert len(scan.ranges)==540 and scan.header.frame_id=='laser'
        assert abs(scan.angle_increment-2*math.pi/540)<1e-7
        assert abs(scan.angle_max-(scan.angle_min+539*scan.angle_increment))<1e-6
        assert scan.time_increment==0 and abs(scan.scan_time-0.1)<0.005
        assert abs(scan.range_min-0.3)<1e-6 and scan.range_max==100
        # Separate DDS topics can arrive out of order; compare a matched timestamp.
        node.wait(lambda:node.latest['cloud'].header.stamp==node.latest['scan'].header.stamp
                  and node.latest['raw_scan'].header.stamp==node.latest['scan'].header.stamp)
        scan, cloud = node.latest['scan'], node.latest['cloud']
        assert cloud.header==scan.header
        assert cloud.width==sum(math.isfinite(v) for v in scan.ranges)
        points = np.array(list(struct.iter_unpack('<ffff', bytes(cloud.data))))
        assert np.max(np.abs(points[:,2]))==0
        laser = node.tf['laser']
        assert laser.header.frame_id=='lidar_link' and abs(laser.transform.rotation.w-1)<1e-6
        assert abs(laser.transform.translation.z - (0.14330766582-0.13023266581539064)) < 1e-6
        assert node.tf['base_footprint'].header.frame_id=='odom'
        assert node.latest['imu'].header.frame_id=='imu_link'
        odom = node.latest['odom']
        q = yaw(odom.pose.pose.orientation)
        x = odom.pose.pose.position.x + math.cos(q)*0.0924721442817
        y = odom.pose.pose.position.y + math.sin(q)*0.0924721442817
        range_checks = {}
        # Forward wall and elevated / low targets: beam stays on the horizontal plane.
        for label, angle in [('front',0), ('low_target',math.atan2(-0.55-y,1.25-x)),
                              ('raised_target',math.atan2(0.55-y,1.25-x)), ('right',-math.pi/2)]:
            index = round((angle-scan.angle_min)/scan.angle_increment)%540
            actual_angle = scan.angle_min + index*scan.angle_increment + q
            expected = expected_wall(actual_angle, x, y)
            actual = scan.ranges[index]
            range_checks[label] = dict(bin=index, measured_m=actual, expected_m=expected, error_m=actual-expected)
            assert math.isfinite(actual) and abs(actual-expected)<0.035, (label, actual, expected)
        # Near box must occlude the wall behind it; nearest surface is x=1.35 or y=1.2.
        angle = math.atan2(1.4-y,1.5-x)
        index = round((angle-scan.angle_min)/scan.angle_increment)%540
        actual_angle = scan.angle_min + index*scan.angle_increment + q
        expected = max((1.35-x)/math.cos(actual_angle),(1.2-y)/math.sin(actual_angle))
        assert abs(scan.ranges[index]-expected)<0.035, ('occlusion',scan.ranges[index],expected)
        range_checks['occlusion'] = dict(bin=index, measured_m=scan.ranges[index], expected_m=expected)
        report['lidar'] = dict(samples=540, frame='laser', time_increment=scan.time_increment,
                               nominal_scan_height_m=0.14330766582,
                               range_checks=range_checks,
                               scan_period_median_s=statistics.median(np.diff(node.scans[-100:])),
                               finite_bins=sum(math.isfinite(v) for v in scan.ranges))
        raw = node.latest['raw_scan']
        report['lidar']['raw_finite_bins'] = sum(math.isfinite(v) for v in raw.ranges)
        report['lidar']['self_filtered_bins'] = sum(math.isfinite(a) and not math.isfinite(b)
                                                    for a,b in zip(raw.ranges,scan.ranges))
        assert report['lidar']['raw_finite_bins'] >= report['lidar']['finite_bins'] > 250
        assert all(not math.isfinite(v) or v > 0.5 for v in scan.ranges)
        (output/'scan_snapshot.json').write_text(json.dumps(dict(
            frame=scan.header.frame_id, stamp_s=seconds(scan.header.stamp),
            angle_min=scan.angle_min, angle_increment=scan.angle_increment,
            ranges=[float(v) if math.isfinite(v) else None for v in scan.ranges],
            raw_ranges=[float(v) if math.isfinite(v) else None for v in raw.ranges],
            laser_world_xy=[x,y], base_world_xy=[odom.pose.pose.position.x,odom.pose.pose.position.y],
            yaw=q), indent=2))
        report['images']={}
        for name in ('head','left','right','overview'):
            message=node.latest[name]
            assert message.encoding in ('rgb8','bgr8')
            array=np.frombuffer(message.data,dtype=np.uint8).reshape(message.height,message.step)[:, :message.width*3].reshape(message.height,message.width,3)
            if message.encoding=='bgr8': array=array[:,:,::-1]
            assert array.std()>8 and array.mean()>5
            PILImage.fromarray(array).save(output/(name+'.png'))
            report['images'][name]=dict(width=message.width,height=message.height,
                                        mean=float(array.mean()),std=float(array.std()),frame=message.header.frame_id)
            if name!='overview':
                assert message.header.frame_id==name+'_camera_optical_frame'
                assert node.latest[name+'_info'].width==message.width
        # Radar motor contract: stop suppresses both public products, resume restores them.
        node.motor.publish(Int8(data=0))
        node.advance(0.4)
        count=node.count['scan']
        cloud_count=node.count['cloud']
        node.advance(0.6)
        assert node.count['scan']==count and node.count['cloud']==cloud_count
        node.motor.publish(Int8(data=1))
        node.wait(lambda:node.count['scan']>count)
        report['motor_stop_resume']='passed'
        report['motion']=[]
        for label, vx, vy, wz in [('forward',0.10,0,0),('strafe',0,0.10,0),('rotate',0,0,0.20)]:
            node.advance(0.3, Twist())
            before=node.latest['odom'].pose.pose
            command=Twist()
            command.linear.x,command.linear.y,command.angular.z=float(vx),float(vy),float(wz)
            node.advance(2.0,command)
            node.advance(0.3,Twist())
            after=node.latest['odom'].pose.pose
            dx,dy=after.position.x-before.position.x,after.position.y-before.position.y
            dyaw=math.atan2(math.sin(yaw(after.orientation)-yaw(before.orientation)),math.cos(yaw(after.orientation)-yaw(before.orientation)))
            report['motion'].append(dict(case=label,dx=dx,dy=dy,dyaw=dyaw))
            if label=='forward': assert 0.16<dx<0.25 and abs(dy)<0.025
            elif label=='strafe': assert 0.16<dy<0.25 and abs(dx)<0.025
            else: assert 0.32<dyaw<0.5 and math.hypot(dx,dy)<0.03
        command=Twist();command.linear.x=0.1
        node.advance(1.0,command,continuous=False)
        before=node.latest['odom'].pose.pose
        node.advance(0.7)
        after=node.latest['odom'].pose.pose
        assert math.hypot(after.position.x-before.position.x,after.position.y-before.position.y)<0.015
        report['command_watchdog']='passed'
        report['status']='passed'
    except Exception as error:
        report['status']='failed'
        report['error']=repr(error)
        raise
    finally:
        node.cmd.publish(Twist())
        node.motor.publish(Int8(data=1))
        (output/'validation.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
        print(json.dumps(report,indent=2,ensure_ascii=False),flush=True)
        node.destroy_node()
        rclpy.shutdown()


if __name__=='__main__': main()
