#!/usr/bin/env bash
# Start the GPU lab, run acceptance, save actual sensor images and renderer proof.
set -euo pipefail
sim_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
sim_container="${DUOJIN_SIM_CONTAINER:-duojin02-sim-acceptance}"
sim_output="${DUOJIN_SIM_OUTPUT:-$sim_root/simulation/results/latest}"
mkdir -p "$sim_output"
if docker inspect "$sim_container" >/dev/null 2>&1; then
  echo "Container already exists: $sim_container. Choose DUOJIN_SIM_CONTAINER for an independent run." >&2
  exit 1
fi
cleanup() {
  docker cp "$sim_container:/tmp/acceptance/." "$sim_output/" >/dev/null 2>&1 || true
  docker stop -t 5 "$sim_container" >/dev/null 2>&1 || true
}
trap cleanup EXIT INT TERM
DUOJIN_SIM_CONTAINER="$sim_container" "$sim_root/simulation/run.sh" --headless noise:=false > "$sim_output/runtime.log" 2>&1 &
sim_runner=$!
for _ in $(seq 1 90); do
  if docker exec "$sim_container" test -r /tmp/duojin02_sim/install/setup.bash 2>/dev/null &&
     docker exec "$sim_container" test -x /tmp/duojin02_sim/install/duojin02_sim/lib/duojin02_sim/device_adapter 2>/dev/null; then break; fi
  kill -0 "$sim_runner" 2>/dev/null || { cat "$sim_output/runtime.log"; exit 1; }
  sleep 1
done
docker exec "$sim_container" bash -c 'source /opt/ros/humble/setup.bash; source /tmp/duojin02_sim/install/setup.bash; python3 /ws/simulation/validate_runtime.py --output /tmp/acceptance'
docker exec "$sim_container" python3 /ws/simulation/validate_pillars.py /tmp/acceptance
docker cp "$sim_container:/tmp/acceptance/." "$sim_output/"
docker cp "$sim_container:/root/.gz/rendering/ogre2.log" "$sim_output/ogre2.log"
python3 - "$sim_output/ogre2.log" <<'PY'
from pathlib import Path
import sys
log=Path(sys.argv[1]).read_text()
assert 'GL_VENDOR = NVIDIA Corporation' in log and 'GL_RENDERER = NVIDIA' in log, 'GPU renderer verification failed'
print('Verified NVIDIA OpenGL renderer')
PY
echo "Evidence saved: $sim_output"
