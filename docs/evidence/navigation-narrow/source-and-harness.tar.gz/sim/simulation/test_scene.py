"""Guard the important runtime overrides and the read-only hardware boundary."""
import hashlib
import math
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'simulation/src/duojin02_sim'))
from duojin02_sim.scene import generate
from duojin02_sim.geometry import inside_convex

DESCRIPTION = ROOT / 'src/duojin01_description'
PROFILE = ROOT / 'simulation/src/duojin02_sim/config/profile.yaml'


def test_runtime_has_one_base_owner_and_preserves_all_visual_geometry(tmp_path):
    source = DESCRIPTION / 'models/dual_arm_mobile/model.sdf'
    before = hashlib.sha256(source.read_bytes()).hexdigest()
    scene, urdf = generate(DESCRIPTION, PROFILE, tmp_path)
    model = ET.parse(scene).getroot().find("world/model[@name='dual_arm_mobile']")
    assert sum(p.get('name').endswith('VelocityControl') for p in model.findall('plugin')) == 1
    assert not any(p.get('name').endswith('MecanumDrive') for p in model.findall('plugin'))
    original = ET.parse(source).getroot().find('model')
    def structure(element):
        return [(e.tag, e.attrib, (e.text or '').strip()) for e in element.iter()]
    assert len(original.findall('.//visual')) == len(model.findall('.//visual'))
    for a, b in zip(original.findall('.//visual'), model.findall('.//visual')):
        assert structure(a.find('geometry')) == structure(b.find('geometry'))
        assert a.findtext('pose') == b.findtext('pose')
        assert b.find('material/pbr/metal') is not None
    assert hashlib.sha256(source.read_bytes()).hexdigest() == before
    assert 'imu_link' in urdf


def test_lidar_has_exact_hardware_grid_without_duplicate_endpoint(tmp_path):
    scene, _ = generate(DESCRIPTION, PROFILE, tmp_path, noise=False)
    sensor = ET.parse(scene).getroot().find('.//sensor[@name="lidar"]')
    h = sensor.find('lidar/scan/horizontal')
    assert int(h.findtext('samples')) == 540
    assert float(h.findtext('max_angle')) == pytest.approx(math.pi-2*math.pi/540)
    assert sensor.findtext('gz_frame_id') == 'laser'
    assert float(sensor.findtext('pose').split()[2]) == pytest.approx(0.013075000004609366)
    assert sensor.find('lidar/noise') is None
    assert float(sensor.findtext('lidar/range/min')) == 0.02
    assert int(sensor.findtext('lidar/visibility_mask')) == 1
    model = ET.parse(scene).getroot().find("world/model[@name='dual_arm_mobile']")
    excluded = model.findall(".//visual[visibility_flags='2']")
    assert excluded == model.findall("link[@name='lidar_link']/visual")
    assert all(v.find('visibility_flags') is None for v in model.findall("link[@name='base_link']/visual"))


def test_extension_packages_are_outside_hardware_build_graph():
    assert not (ROOT/'src/duojin02_sim').exists()
    package = ET.parse(ROOT/'simulation/src/duojin02_sim/package.xml').getroot()
    assert package.findtext('name') == 'duojin02_sim'
    assert 'ros_gz_bridge' in [e.text for e in package.findall('exec_depend')]
    for path in (ROOT/'src').rglob('package.xml'):
        assert 'duojin02_sim' not in path.read_text()


def test_laser_tf_and_gpu_sensor_agree_at_reserved_layer_midpoint(tmp_path):
    scene, text = generate(DESCRIPTION, PROFILE, tmp_path)
    model = ET.parse(scene).find("world/model[@name='dual_arm_mobile']")
    z = float(model.findtext("link[@name='lidar_link']/pose").split()[2])
    offset = float(model.findtext("link[@name='lidar_link']/sensor/pose").split()[2])
    assert z+offset == pytest.approx(0.14330766582)
    assert 0.13230766582 < z+offset < 0.15430766582
    assert float(model.findtext("frame[@name='laser']/pose").split()[2]) == offset
    urdf = ET.fromstring(text)
    joint = next(j for j in urdf.findall('joint') if j.find('child').get('link')=='laser')
    assert float(joint.find('origin').get('xyz').split()[2]) == offset


def test_chassis_filter_preserves_external_obstacles_and_handles_both_windings():
    polygon = [[.213,.191465],[.201465,.203],[-.202879,.203],[-.214,.191879],
               [-.214,-.190465],[-.201465,-.203],[.202879,-.203],[.213,-.192879]]
    for outline in (polygon,list(reversed(polygon))):
        assert inside_convex(-.209, .01, outline)
        assert inside_convex(.09, 0, outline)
        assert not inside_convex(.30, 0, outline)
        assert not inside_convex(-.22, .21, outline)
