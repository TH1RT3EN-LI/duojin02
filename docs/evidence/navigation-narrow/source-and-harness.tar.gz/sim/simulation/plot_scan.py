#!/usr/bin/env python3
"""Plot a recorded LaserScan against the measured chassis and known scene."""
import json
import math
from pathlib import Path
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Rectangle
import numpy as np

root = Path(__file__).resolve().parents[1]
folder = Path(sys.argv[1]) if len(sys.argv)>1 else root/'simulation/evidence'
scan = json.loads((folder/'scan_snapshot.json').read_text())
measurements = json.loads((root/'docs/chassis/measurements.json').read_text())
angles=scan['angle_min']+np.arange(len(scan['ranges']))*scan['angle_increment']+scan['yaw']
ranges=np.array([np.nan if v is None else v for v in scan['ranges']])
origin=np.array(scan['laser_world_xy'])
xy=origin+np.column_stack((ranges*np.cos(angles),ranges*np.sin(angles)))
figure, ax=plt.subplots(figsize=(9,8))
ax.add_patch(Rectangle((-3,-2.5),6,5,fill=False,edgecolor='#374151',linewidth=2,label='Wall surfaces'))
for label, corner, width, height, color in [
    ('Below scan plane',(1.125,-.675),.25,.25,'#e8a328'),
    ('Above scan plane',(1.125,.425),.25,.25,'#43a38f'),
    ('Opaque occluder',(1.35,1.2),.3,.4,'#de6149')]:
    ax.add_patch(Rectangle(corner,width,height,facecolor=color,alpha=.5,label=label))
ax.scatter(xy[:,0],xy[:,1],s=10,color='#1476c6',label='Actual GPU scan hits')
if 'raw_ranges' in scan:
    raw=np.array([np.nan if v is None else v for v in scan['raw_ranges']])
    excluded=np.isfinite(raw)&~np.isfinite(ranges)
    raw_xy=origin+np.column_stack((raw*np.cos(angles),raw*np.sin(angles)))
    ax.scatter(raw_xy[excluded,0],raw_xy[excluded,1],s=10,color='#f97316',label='Filtered chassis self hits')
for point in xy[::15]:
    if np.isfinite(point).all(): ax.plot([origin[0],point[0]],[origin[1],point[1]],color='#1476c6',alpha=.15,lw=.7)
# Footprint is chassis-only; upper arms are excluded according to user scope.
nav = root/'src/duojin01_bringup/config/nav2.yaml'
import yaml
document=yaml.safe_load(nav.read_text())
params=document['local_costmap']['local_costmap']['ros__parameters']
footprint=np.array(json.loads(params['footprint']))
c,s=math.cos(scan['yaw']),math.sin(scan['yaw'])
footprint=footprint@np.array([[c,s],[-s,c]])+scan['base_world_xy']
ax.add_patch(Polygon(footprint,facecolor='#64748b',alpha=.8,label='Chassis footprint'))
ax.plot(*origin,'o',color='#e62851',markersize=6,label='Laser optical origin')
ax.arrow(*origin,.45*c,.45*s,width=.01,color='#e62851',length_includes_head=True)
ax.set(xlim=(-3.4,3.4),ylim=(-2.9,2.9),xlabel='World X (m)',ylabel='World Y (m)',
       title='Recorded 540-bin GPU lidar: plane in reserved chassis slot (143.308 mm)')
ax.set_aspect('equal');ax.grid(alpha=.18);ax.legend(loc='lower left',fontsize=8)
figure.tight_layout()
figure.savefig(folder/'lidar_validation.png',dpi=170)
figure.savefig(folder/'lidar_validation.svg')
