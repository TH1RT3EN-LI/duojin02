# 本地 GPU 仿真

本目录是 `sim` 的独立兼容层。包位于 `simulation/src`，不进入 `src` 七个真机包的构建图。导航算法和参数从 main 单向同步，仿真只覆盖时钟与设备输入。宿主机、`main` 和串口设备不需要安装或启动 Gazebo。

## 环境与启动

选用 Ubuntu 22.04 / ROS 2 Humble / Gazebo Harmonic 8。保留真机的 Humble 接口，使用官方提供的非默认配对 `ros-humble-ros-gzharmonic`，避免与 Humble 默认的 Fortress 桥接混装。[Gazebo 配对说明](https://gazebosim.org/docs/harmonic/ros_installation/)。

本机已构建 `duojin02:sim-humble-harmonic`，在 RTX 5070 12 GB / 驱动 580.178.04 上验证。实际版本为 Gazebo Sim **8.12.0**、rendering **8.2.3**、sensors **8.2.2**、ros-gzharmonic **0.244.12**。基础缓存镜像为 `duojin01:humble-harmonic`，ID `7be35551e7d9e2c155a875e2556c01694e68e6dfb528a952276a2572f255c9b7`。Dockerfile 也支持从官方 ROS Jammy 基础镜像安装；新建环境的补丁版本应重新记录、验证。

在仓库根目录执行：

```bash
./simulation/run.sh --build
./simulation/run.sh --headless
# 本机 X11/XWayland 有 DISPLAY、XAUTHORITY 时可打开 Gazebo 窗口
./simulation/run.sh --gui
# 同时打开三路相机、实时建图和雷达检查窗口
./simulation/run.sh --gui mapping:=true rviz:=true
# 在线建图 + 标准 NavigateToPose 导航 + 全速度保护
./simulation/run.sh --gui mapping:=true navigation:=true rviz:=true
```

`--headless` 仍使用显卡：Ogre2 + EGL，无需 X 窗口。容器传入 `--gpus all` 和 `graphics,display,utility,compute` 能力，不设置软件 GL。官方 [EGL 说明](https://gazebosim.org/api/sim/8/headless_rendering.html)；GPU 使用的是 OpenGL 渲染链路，不是 CUDA 数值求解。容器每次在 `/tmp` 构建 description、原有 bringup 和新 sim 包，源码只读挂载。默认隔离在 ROS domain **72**、GZ partition **duojin02_lab**、容器名 **duojin02-sim-lab**，不与真机 domain 20 通信。

```bash
# 独立终端进入当前容器
docker exec -it duojin02-sim-lab bash
source /opt/ros/humble/setup.bash
source /tmp/duojin02_sim/install/setup.bash
ros2 topic echo /scan --once
# 持续发布，Ctrl+C 后 0.5 秒仿真时间内停车
ros2 topic pub -r 20 /cmd_vel geometry_msgs/msg/Twist '{linear: {x: 0.1, y: 0.0}, angular: {z: 0.0}}'
```

可覆盖 `DUOJIN_SIM_IMAGE`、`DUOJIN_SIM_CONTAINER`、`DUOJIN_SIM_DOMAIN`、`DUOJIN_SIM_PARTITION`。构建时用 `DUOJIN_SIM_BASE_IMAGE=ros:humble-ros-base-jammy` 强制清洁基础环境。退出前台启动用 Ctrl+C；也可执行 `docker stop -t 5 duojin02-sim-lab`。无窗口和桌面 GUI 都已实际启动并确认 NVIDIA renderer；GUI 的默认近景视角配置在 `config/gui.config`。

本次留在桌面的窗口使用容器 `duojin02-sim-preview`、domain **74**、partition **duojin02_preview**。复现启动命令：

```bash
DUOJIN_SIM_DOMAIN=74 DUOJIN_SIM_PARTITION=duojin02_preview DUOJIN_SIM_CONTAINER=duojin02-sim-preview \
  ./simulation/run.sh --gui mapping:=true rviz:=true
```

`mapping:=true` 复用 hardware 镜像内固定的 SLAM Toolbox 覆盖层，提交 `8293d21fe5c816d0405e0cc1f3eb46c70659c267` / 版本 2.6.10，含原项目补丁；Dockerfile 从 `duojin01:hardware-humble` 复制这份既有构建。SLAM 参数同步 main 的 1 cm 配置，只在启动时覆盖仿真时钟。清洁机器需先按仓库真机镜像说明构建该镜像，再构建 sim 镜像。

RViz2 配置包含整机、`/map`、黄色 `/sim/lidar/raw`、红色 `/scan`，以及头部、左腕、右腕三路图像。Views 中保存 **Map overhead** 和 **Lidar layer inspection** 两个视角；后者可贴近检查立柱与扫描平面。地图由真实模拟扫描生成，初始静止状态信息有限；移动后会逐步更新。

## 模型、材质和场地

移除拖链与隐藏内部结构后已重新完成 GPU 验收：四路图像、540 束雷达、点云、TF、前进／横移／旋转与指令超时停车通过。RTX 5070 实时因子为 **0.963**（10 s 模拟时间 / 10.386 s 实际耗时），来源见 [当前模型验收](../docs/evidence/hidden-detail/gazebo/validation.json)。硬件边界、底盘、模型与运行场景共 **31 项**检查通过。

使用 **3,092,505 三角面、58 个 DAE 网格** 的 `native-shell` 版本。外壳、轮子及外部紧固件恢复原生网格和 CAD 保存的法线，视觉网格不减面；缺失的舵机外形复用原生中壳 / 舵盘与官方 STEP 上下盖。移除底盘内的大电池及两块带散热片的稳压模块，保留顶部可见的蓝色电池。壳体恢复对比见 [comparison.png](../docs/evidence/native-shell/comparison.png)，舵机补全见 [servo-restoration/comparison.png](../docs/evidence/servo-restoration/comparison.png)。运行时从已审阅的模型生成 `/tmp/duojin02-lab-*/lab.sdf`，不会改动源 SDF、网格、URDF 或资产清单。`duojin02_sim/scene.py` 是所有运行时补充的唯一入口，`config/profile.yaml` 控制传感器、材质和底盘参数。

Ogre2 的 PBR 金属工作流给金属、涂层、橡胶、传感器外壳分别配置 metalness / roughness。材质是按 CAD 部件语义重建的显示参数，未测量实物 BRDF；几何和位置保留。轮子两侧侧板独立设为银色，滚子、轴销与中央轮毂保留深色；胸甲和头部下方立柱与头壳统一为深灰色，更新验证见 [model-colors](../docs/evidence/model-colors/geometry-validation.json)。显示网格与简化的碰撞体分开；GPU 雷达和相机看到显示几何，刚体碰撞使用碰撞体。场地有地面网格、四面已知坐标的墙、遮挡柱、低物体及悬空物体；不依赖联网下载 Fuel 模型。

三路原有机载相机为 **640×480 / 15 Hz**；外部观察相机为 **1280×720 / 15 Hz**，用于观察整机和保存实拍。图像桥接按订阅惰性启用，单独启动没有图像订阅时的负载较低。观察相机的 frame 是世界固定的记录相机，不作为机载 TF 或标定源。

## 雷达机制与接口

雷达是 `gpu_lidar`，由 Ogre2 渲染场景深度获取每个角度最近的可见表面。扫描平面设置为 **(0.092472, -0.000009, 0.143308) m**；`laser` 的 +X 和用户确认的三角零度标记均朝车头，ROS 角度逆时针增加。原先 130.233 mm 的壳体中平面代值低于下层装饰外壳顶部约 2.075 mm，不能代表预留扫描层。原生 CAD 测得下层外壳顶面 **132.308 mm**、上层面板底面 **154.308 mm**，净空 **22.0 mm**；当前仿真取净空中点 **143.308 mm**。只覆盖运行时传感器和对应 TF，不移动显示外壳，不修改 main；真实 N10Plus 的光学高度仍需实物标定。测算见 [lidar-layer.json](evidence/lidar-layer.json)，图示见 [lidar-layer-inspection.png](evidence/lidar-layer-inspection.png)。

数据流程：`GPU 深度 → /sim/lidar/raw → 底盘自身回波过滤 → /scan + /lslidar_point_cloud`。原始回波保留在 `/sim/lidar/raw`，过滤由独立 device_adapter 完成，未改动真机雷达驱动。桥接配置可在启动日志给出的临时目录检查。[官方 ROS 桥接说明](https://gazebosim.org/docs/harmonic/ros2_integration/)。

| 参数或行为 | 当前配置及依据 |
| --- | --- |
| 扫描格数 / 频率 | 540 / 10 Hz，匹配当前 N10Plus 驱动契约 |
| 角度 | `angle_min=-π`，增量 `2π/540`，末格 `π-2π/540`；不重复 -π/+π |
| 逐束时间 | `time_increment=0`，与真机角度重排后的语义相同；`scan_time` 取帧时间差 |
| 渲染近裁剪 | 0.02 m，让底盘内近处立柱先参与遮挡；属于模拟参数，未标定设备光学盲区 |
| 公开输出最近距离 | 0.30 m，沿用真机过滤配置，在最近表面判定后执行 |
| 光学测试范围 | 默认 10 m，是可调整的仿真工况；未标定这台 N10Plus 的极限量程 |
| 输出 `range_max` | 100 m，兼容现有驱动过滤配置；不表示实际能测到 100 m，超过仿真量程无回波 |
| 距离噪声 | 默认独立高斯 σ=5 mm，属于假设测试参数；`noise:=false` 做几何验收 |
| 无效距离 | `+inf`；无效强度 `NaN` |
| 强度 | 有效束固定为 1，避免把 PBR 颜色冒充 905 nm 的反射强度 |
| 点云 | 同一时间戳、`laser` frame、XYZI float32；Z=0，每个有效格一个最近回波 |
| `/motor_control` | Int8：0 暂停 `/scan` 和点云输出，1 恢复；其他值忽略 |

雷达水平束不会发现完全低于或高于扫描平面的障碍物；遮挡物后面只返回最近表面。预留层的 **6 根二层连接柱** 保留原生几何并参与遮挡。无噪声验收中逐根将原始回波与 CAD 平面截线求交比较，分别命中 **11 / 9 / 7 / 11 / 9 / 7 格**，合计 **54 格**；中间束距离约 **122.5 / 162.5 / 242.5 mm**，柱边缘距离误差不超过 6.6 mm。验证记录见 [pillar-validation.json](evidence/pillar-validation.json)。

必须分开光学近裁剪和驱动输出过滤：如果直接用 0.30 m 裁剪 GPU 场景，会跳过这些更近的立柱并错误看见后方墙面。当前先渲染 0.02 m 以外最近表面，再按 0.30 m 最小距离及继承的底盘八边形过滤自身回波，置为 `+inf`；不会生成被遮挡的远处墙面或插值补点。原始扫描 **540 格**有效，公开扫描 **484 格**有效，总计 **56 格**被过滤，其中 54 格由立柱遮挡。RViz2 的黄色原始扫描可显示近处回波；红色公开扫描保留这些方向的缺口。`self_filter: false` 仅关闭底盘多边形过滤，输出最小距离过滤仍生效。

CAD 雷达外壳没有建模透光窗口，因此仅该传感器自己的外壳使用独立可见性标记，从自身 GPU 光束中排除；它仍出现在 RGB 图像中。车身、六根立柱及外部障碍物全部保持可见。该处理修正 CAD 显示外壳与光学窗口的差异，不是移除底盘遮挡。原真机驱动未改动，仿真高度也不作为修改真机标定的依据。[Gazebo GPU lidar 实现](https://github.com/gazebosim/gz-sensors/blob/gz-sensors8/src/GpuLidarSensor.cc) 中近裁剪由 RangeMin 设置。

默认 5 mm 距离噪声也已测试，80 帧静止前向墙面测得标准差约 **5.05 mm**，记录在 [noise-validation.json](evidence/noise-validation.json)。实际扫描叠图见 [lidar_validation.png](evidence/lidar_validation.png)，橙色为已过滤的自身回波。

当前不模拟真机的 108 字节串口包、双回波硬件、旋转过程中的逐束采样／运动畸变、905 nm 波长反射率、玻璃折射与穿透、黑色目标丢点和阳光干扰。`/scan` 的最近距离语义可以兼容导航，但原驱动原始点云可能包含两次回波；这里的点云仅有一次。电机控制只模拟输出停启，停止时 GPU 原始传感器继续渲染。不能用此模型判定真实玻璃、黑色目标或强光下的检出率。

厂商 [N10 产品页](https://www.lslidar.com/product/n10-navigation-obstacle-avoidance-lidar/) 给出的参数属于 N10 产品，不能直接当作这台 N10Plus 的实测标定。这里优先遵循仓库已确定的 N10Plus ROS 输出契约，并把未测物理参数留在独立配置中。

## 底盘与其他设备

原 staged SDF 同时存在全车 VelocityControl 和 MecanumDrive。运行时去掉两者，再添加 **唯一 VelocityControl** 管全车速度；四个 JointController 只按麦克纳姆逆运动学转动显示轮，`/odom` 从 Gazebo 实际模型位姿得到。不会把编码器积分当作真实位移。轮距、轴距来自已测 CAD；轮半径是滚子包络半径，仅用于动画。

这是适合 SLAM／导航接口测试的 **kinematic 模式**。轮子碰撞体仍是圆柱，质量、惯量及关节限制仍包含估计值，不能评估真实滚子摩擦、打滑、负载能力或制动距离。VelocityControl 是直接速度伺服，碰撞也不等价于电机扭矩驱动。完整麦克纳姆滚子接触力学需要后续单独模型和实物参数。

复用 twist_mux 的三路输入，并经过 main 的 velocity_guard / Collision Monitor 到 `/cmd_vel_base`；仿真适配器增加 0.5 s 指令超时停车。ROS、Gazebo 和所有新增节点使用仿真时钟。原有 EKF 和其参数原样复用，仅在独立 launch 覆盖 `use_sim_time=true`。动态 `odom→base_footprint` TF 由 EKF 单独发布；Gazebo truth TF 不桥接到 `/tf`，防止双重发布。

`/odom` 是理想仿真真值，`/imu` 来自 Gazebo 的 IMU 系统，外参沿用真机待标定的零偏移；给出的协方差是测试配置。`/battery_voltage` 固定为 24 V，没有电池消耗模型。整机 `/joint_states` 由 Gazebo 发布；RSP 使用运行时扩展的独立整机 URDF。双臂、升降和手指保留原来平滑 JointTrajectory 接口 `/dual_arm/joint_trajectory`；硬件仅底盘描述入口不受影响。

本次配置和验收覆盖 Gazebo、GPU、模型、设备接口、EKF、TF、三路相机和实际 SLAM 建图。仿真底盘以 0.1 m/s 走过约 0.6 m 方形轨迹并停车，地图分辨率 **3 cm**、**201×168** 格，包含 **852 个占用格、31,602 个自由格**；实际栅格和轨迹保存在 [slam-map.png](evidence/slam-map.png)、[map-validation.json](evidence/map-validation.json)、[map-motion.json](evidence/map-motion.json)。地图中的未知区域包含外部障碍物后的遮挡区。该次历史验收未做 Nav2 路径跟踪和真实硬件验收；新增导航验证见下方。

## 测试与证据

```bash
./simulation/test.sh
```

自动启动独立 GPU 容器，关闭距离噪声，检查四路图像、scan / 点云时间戳及内容一致性、坐标系、已知墙面距离、六根立柱遮挡和扫描高度、雷达停启、前进／横移／旋转及指令失联停车。记录实际安装的资产 profile、面数、网格数和 SDF 哈希。结束后释放容器，产物写入 `simulation/results/latest`；`DUOJIN_SIM_OUTPUT` 可更换输出目录。

立柱过滤验收的结果在 [evidence/validation.json](evidence/validation.json)，外部实拍为 [overview.png](evidence/overview.png)。该次使用舵机补全前的 **1,264,283 面 / 47 网格**模型，四路相机的 NVIDIA 实测为 **10 s 仿真 / 10.138 s 实际**，实时因子约 **0.986**；雷达 10 Hz、相机 15 Hz，当时 **30 项**回归检查通过。补全后的当前资产验收见上面的“模型、材质和场地”。详细立柱过滤数据和渲染设备日志存于 `evidence`。软件渲染仅作为历史显卡收益对照，不是默认启动模式。

在已启动的隔离仿真容器内可复现噪声和建图检查：

```bash
docker exec duojin02-sim-preview bash -c 'source /opt/ros/humble/setup.bash; source /tmp/duojin02_sim/install/setup.bash; python3 /ws/simulation/probe_noise.py'
# 此命令会在仿真内走一圈，结束时停车，输出实际地图、PGM 与 YAML
docker exec duojin02-sim-preview bash -c 'source /opt/ros/humble/setup.bash; source /tmp/duojin02_sim/install/setup.bash; python3 /ws/simulation/probe_map.py --drive-square'
```

| 历史对照：51.7 万面模型与四路相机的渲染器 | 模拟时间 / 实际耗时 | 实时因子 |
| --- | --- | --- |
| NVIDIA RTX 5070，Ogre2/EGL | 10 s / 约 10.1 s | 约 0.99 |
| Mesa llvmpipe，软件 GL | 3 s / 45.10 s | 0.0665 |

显卡约快 **15 倍**，维持雷达 10 Hz、机载和外部相机 15 Hz（按仿真时间）。对照采样时长不同，属于本场地工作负载的测量，不是所有场景的通用性能结论。OpenGL 的实际 vendor / renderer 日志同时保存；`nvidia-smi` 可见显卡不是唯一判据。

Gazebo 8 的 `gz_frame_id` 是扩展字段，SDF 校验会给出复制未知字段的提示，运行时和桥接识别正确；本机 EGL 启动也会先打印 Mesa dri2 探测警告，随后实际选择 NVIDIA。验收以最终 renderer、传感器输出及数值检查为准。

## 2026-10-06 定位与避障升级

算法来源为 duojin02/main，单向同步到本分支；真实 CAD、网格和仿真专用资产保留。目标板卡是 Orin Nano 8GB / JetPack 6.2 / 单二维雷达，碰撞范围为底盘含四轮。新版含 Smac Lattice、MPPI Omni、窄处低速 SE2 跟踪、制动扫掠保护和雷达盲区障碍记忆。新地图默认 1 cm，已保存地图遵循实际分辨率并生成匹配的原语。

启动真正的在线 SLAM + 导航（不启动 AMCL / map server）：

```bash
./simulation/run.sh --build
./simulation/run.sh --gui mapping:=true navigation:=true rviz:=true
```

`navigation:=false` 仅建图。`mapping:=false navigation:=true map:=...` 为实时固定地图导航。所有速度来源默认经过保护，`guard:=false` 仅用于旧版对照。启动顺序为定位 → 新鲜扫描和 map/odom TF 就绪 → 导航；目标发送前确认生命周期 ACTIVE。默认 Cyclone DDS，显式 RMW_IMPLEMENTATION 仍可覆盖。

独立挑战场景对照（在 main 硬件仓库旁运行，默认挂载 ../duojin02 为只读）：

```bash
./simulation/navigation_benchmark.sh --cases open corridor_0.56 corridor_0.50 thin_obstacles s_bend dynamic_crossing sensor_dropout initial_pose_error online_thin unsafe_command --seeds 1 2 3
```

`DUOJIN_HARDWARE_SOURCE` 指定硬件源码，`DUOJIN_NAV_OUTPUT` 指定产物目录。每个试验保存配置、源码和二进制哈希、场景与障碍刺激、真实轨迹、定位/碰撞/耗时/CPU/RSS 指标。试验不向估计器或导航注入真值位姿；在线 SLAM 不使用生成的先验地图。真实底盘按 4 mm 角部行程插值检查几何碰撞。强制危险命令属于应停车测试。

研究与完整结果见 [导航升级报告](../docs/navigation-upgrade-review.md)；本机模拟与真机 Orin 的实时性、停车距离仍须分开验收。

## 速度与精确停稳回归（2026-10-07）

新版常规前进上限 0.50 m/s、横移 0.30 m/s、后退 0.20 m/s；短段 Omni 跟踪进行填充 footprint 扫掠检查，阻塞时使用 MPPI。窄区先对齐再降速，所有输出仍经过制动保护。平滑器采用 OPEN_LOOP 指令递推，保护层继续依据测得的速度检查制动。StableStoppedGoalChecker 要求 XY/yaw/速度连续满足 0.25 s 才返回成功。

```bash
./simulation/navigation_performance_matrix.sh
```

矩阵为 12 场景 × 6 种子，另做同种子旧版比较、窄门拒绝、传感器中断和受限 CPU 测试。严格验收使用独立真值：位置 ≤20 mm、朝向 ≤0.035 rad、末端速度 ≤0.020 m/s、无碰撞。完整结果与原始失败记录见 [速度与到达精度报告](../docs/navigation-performance-review.md)。受限桌面容器不代表 Orin 原生实测。

## 窄门与精确停靠回归（2026-10-07）

main 算法使用精确全局直连、窄处居中、完整速度制动检查和 4 mm 估计停靠阈值。在线局部避障使用雷达与盲区记忆，全局地图与地图先验保护保留。默认恢复树采用清图、受保护慢速后退和等待。

```bash
./simulation/navigation_narrow_matrix.sh
```

最终矩阵包含 13 场景 × 6 新种子，未知 50 cm 门计入主分母；保存五级速度指令链，保持原真值碰撞、20 mm 位置、朝向和停稳验收。完整结果、历史失败与适用边界见 [窄门与停靠报告](../docs/navigation-narrow-review.md)。
