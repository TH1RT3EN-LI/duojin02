"""Record and later verify exact sources and compiled navigation binaries."""
import hashlib
import json
import platform
import subprocess
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    root=Path('/hardware');build=Path('/tmp/navbuild')
    sources=list((root/'src/duojin01_navigation').rglob('*'))
    sources += list((root/'src/duojin01_bringup/config').rglob('*'))
    sources += list(Path('/ws/simulation/src').rglob('*'))
    sources=[p for p in sources if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith('.pyc')]
    binaries=list((build/'install/duojin01_navigation/lib').glob('*.so'))
    binaries += [build/'install/duojin01_navigation/lib/duojin01_navigation/velocity_guard']
    manifest=dict(sources={str(p):digest(p) for p in sources},binaries={str(p):digest(p) for p in binaries})
    manifest['platform']=dict(architecture=platform.machine(),kernel=platform.release(),
      packages=subprocess.run(['dpkg-query','-W','ros-humble-nav2-smac-planner','ros-humble-nav2-mppi-controller',
                              'ros-humble-nav2-amcl','libgz-sim8'],capture_output=True,text=True,check=True).stdout)
    (build/'navigation-build.json').write_text(json.dumps(manifest,indent=2))
    print('Saved compiled navigation manifest')


if __name__=='__main__':main()
