#!/usr/bin/env python3
"""Check the default noise profile from actual stationary scans, inside container."""
import json
from pathlib import Path
import statistics
from validate_runtime import Probe
import rclpy

rclpy.init()
node=Probe()
node.wait(lambda:'scan' in node.latest and 'clock' in node.latest)
node.advance(2)
values=[]
last=None
def collect():
    global last
    message=node.latest['scan']
    stamp=(message.header.stamp.sec,message.header.stamp.nanosec)
    if stamp != last:
        last=stamp
        values.append(message.ranges[270])
    return len(values)>=80
node.wait(collect,timeout=35)
stddev=statistics.stdev(values)
report=dict(samples=len(values),configured_stddev_m=0.005,measured_stddev_m=stddev,
            mean_range_m=statistics.mean(values),status='passed' if 0.0025<stddev<0.008 else 'failed')
Path('/tmp/noise-validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
assert report['status']=='passed'
node.destroy_node();rclpy.shutdown()
