#!/usr/bin/env bash
set -eo pipefail
source /opt/ros/humble/setup.bash
source /opt/duojin01/slam_backend/setup.bash
mkdir -p /tmp/duojin02_sim
cd /tmp/duojin02_sim
colcon --log-base log build --base-paths /ws/src/duojin01_description \
  /ws/src/duojin01_bringup /ws/src/duojin01_navigation /ws/simulation/src --build-base build --install-base install \
  --event-handlers console_direct+ --cmake-args -DCMAKE_BUILD_TYPE=Release
source /tmp/duojin02_sim/install/setup.bash
exec ros2 launch duojin02_sim lab.launch.py "$@"
