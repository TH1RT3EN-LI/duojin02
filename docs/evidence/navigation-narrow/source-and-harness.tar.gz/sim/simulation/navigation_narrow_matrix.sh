#!/usr/bin/env bash
# Final frozen verification includes online narrow-door trials in its denominator.
set -euo pipefail
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$script_dir/navigation_benchmark.sh" --variants upgraded --seeds 44 45 46 47 48 49 \
  --cases open corridor_0.50 thin_obstacles s_bend dynamic_crossing sensor_dropout \
    initial_pose_error online_thin online_open office_chicane online_chicane reverse_goal \
    online_corridor_0.50 "$@"
