"""Validate staged simulator frames against CAD and preserved assembly geometry."""
import hashlib
import json
from pathlib import Path
import struct
import xml.etree.ElementTree as ET

import pytest


ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT / "src/duojin01_description"
MODEL = PACKAGE / "models/dual_arm_mobile"
DATA = json.loads((ROOT / "docs/chassis/measurements.json").read_text())
ALIGNMENT = json.loads((MODEL / "hardware_alignment.json").read_text())
SDF = ET.parse(MODEL / "model.sdf").getroot().find("model")
URDF = ET.parse(PACKAGE / "urdf/dual_arm_mobile.urdf").getroot()


def values(text, count=6):
    return list(map(float, (text or " ".join(["0"] * count)).split()))


def urdf_positions():
    positions = {"base_footprint": [0., 0., 0.]}
    pending = list(URDF.findall("joint"))
    while pending:
        resolved = []
        for joint in pending:
            parent, child = joint.find("parent").get("link"), joint.find("child").get("link")
            if parent in positions:
                # Parent rotations are zero on every CAD body in this staged rig;
                # only leaf optical frames have nonzero rotations.
                local = values(joint.find("origin").get("xyz"), 3)
                positions[child] = [positions[parent][i] + local[i] for i in range(3)]
                resolved.append(joint)
        assert resolved, "URDF contains a disconnected link or cycle"
        pending = [joint for joint in pending if joint not in resolved]
    return positions


def test_wheel_frames_and_collision_dimensions_match_hardware():
    positions = urdf_positions()
    for name, wheel in DATA["wheels"].items():
        link_name = name + "_wheel"
        link = SDF.find(f"link[@name='{link_name}']")
        assert values(link.findtext("pose"))[:3] == pytest.approx(wheel["center_xyz_m"], abs=1e-9)
        assert positions[link_name] == pytest.approx(wheel["center_xyz_m"], abs=1e-9)
        cylinder = link.find("collision/geometry/cylinder")
        assert float(cylinder.findtext("radius")) == pytest.approx(wheel["radial_envelope_radius_m"], abs=1e-10)
        assert float(cylinder.findtext("length")) == pytest.approx(.05, abs=1e-7)
        assert values(link.findtext("collision/pose"))[:3] == [0., 0., 0.]
    drive = SDF.find("plugin[@name='gz::sim::systems::MecanumDrive']")
    assert float(drive.findtext("wheelbase")) == pytest.approx(DATA["wheelbase_m"], abs=1e-9)
    assert float(drive.findtext("wheel_separation")) == pytest.approx(DATA["track_width_m"], abs=1e-9)
    bounds = DATA["chassis_body_collision_bounds_m"]
    body = SDF.find("link[@name='base_link']/collision")
    assert values(body.findtext("pose"))[:3] == pytest.approx([(a + b) / 2 for a, b in zip(*bounds)], abs=1e-9)
    assert values(body.findtext("geometry/box/size"), 3) == pytest.approx([b - a for a, b in zip(*bounds)], abs=1e-9)


def test_laser_frame_matches_hardware_without_claiming_optical_calibration():
    assert urdf_positions()["laser"] == pytest.approx(DATA["lidar"]["nominal_scan_xyz_m"], abs=1e-9)
    frame = SDF.find("frame[@name='laser']")
    assert frame.get("attached_to") == "lidar_link"
    assert frame.find("pose").get("relative_to") == "lidar_link"
    assert values(frame.findtext("pose")) == pytest.approx([0., 0., 0., 0., 0., DATA["lidar"]["nominal_yaw_rad"]])
    sensor = SDF.find("link[@name='lidar_link']/sensor")
    assert sensor.findtext("gz_frame_id") == "laser"
    assert values(sensor.findtext("pose")) == values(frame.findtext("pose"))
    assert ALIGNMENT["scan_height_status"] == DATA["lidar"]["scan_height_status"]
    assert ALIGNMENT["selected_navigation_projection"] == "chassis"


def test_reference_frame_change_preserves_all_visual_assembly_positions():
    anchor = DATA["cad_ros_base_origin_xyz_m"]
    positions = urdf_positions()
    for name, reference in ALIGNMENT["reference"]["links"].items():
        link = SDF.find(f"link[@name='{name}']")
        current = values(link.findtext("pose"))
        assert positions[name] == pytest.approx(current[:3], abs=2e-9)
        peer = URDF.find(f"link[@name='{name}']")
        assert len(link.findall("visual")) == len(reference["visuals"]) == len(peer.findall("visual"))
        for visual, original, urdf_visual in zip(link.findall("visual"), reference["visuals"], peer.findall("visual")):
            expected = [reference["pose"][i] + original[i] - anchor[i] for i in range(3)]
            local = values(visual.findtext("pose"))
            assert [current[i] + local[i] for i in range(3)] == pytest.approx(expected, abs=2e-9)
            origin = urdf_visual.find("origin")
            local_urdf = values(origin.get("xyz") if origin is not None else None, 3)
            assert [positions[name][i] + local_urdf[i] for i in range(3)] == pytest.approx(expected, abs=2e-9)


def test_reviewed_meshes_and_glb_geometry_match_current_asset_revision():
    paths = sorted((MODEL / "meshes").glob("*.dae"))
    report = json.loads((MODEL / "conversion_report.json").read_text())
    assert len(paths) == len(report["meshes"])
    assert {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in paths} == ALIGNMENT["reference"]["mesh_sha256"]
    manifest = json.loads((MODEL / "asset_manifest.json").read_text())
    for path, expected in manifest["sha256"].items():
        assert hashlib.sha256((PACKAGE / path).read_bytes()).hexdigest() == expected
    glb = (MODEL / "preview.glb").read_bytes()
    size = struct.unpack_from("<I", glb, 12)[0]
    assert hashlib.sha256(glb[20 + size:]).hexdigest() == ALIGNMENT["reference"]["glb_binary_sha256"]
    document = json.loads(glb[20:20 + size])
    anchor = DATA["cad_ros_base_origin_xyz_m"]
    for scene in document["scenes"]:
        assert len(scene["nodes"]) == 1
        root = document["nodes"][scene["nodes"][0]]
        assert root["name"] == "hardware_base_frame"
        assert root["translation"] == pytest.approx([-anchor[0], -anchor[2], anchor[1]])


def test_native_shell_profile_preserves_surfaces_and_only_culls_named_internals():
    report = json.loads((MODEL / "conversion_report.json").read_text())
    assert report["quality_profile"] == "native-shell"
    assert report["visual_triangles"] == sum(mesh["triangles"] for mesh in report["meshes"])
    for mesh in report["meshes"]:
        assert mesh["triangles"] == mesh["source_triangles"]
        assert mesh["normals"].startswith("native CAD corner normals")
    retained = {part["source_path"]: part for part in report["retained_parts"]}
    reviewed_removals = {p["source_path"] for p in report.get("detail_removal", {}).get("removed_instances", [])}
    assert not reviewed_removals & set(retained)
    for part in report["original_retained_parts"]:
        if part["model_id"] not in {"103", "138"} and part["source_path"] not in reviewed_removals:
            assert retained[part["source_path"]]["link"] == part["link"]
    assert not any(p["model_id"] == "97" or "/BKLM-F37-R28-N20-BKTM" in p["source_path"] for p in retained.values())
    assert any(part["model_id"] == "88" for part in retained.values()), "Exposed top battery must stay"
    internal = [part for part in report["removed_instances"] if part["reason"].startswith("enclosed")]
    assert sorted(part["model_id"] for part in internal) == ["103", "138", "138"]
    ns = {"c": "http://www.collada.org/2005/11/COLLADASchema"}
    for mesh in report["meshes"]:
        path = MODEL / "meshes" / (mesh["link"] + "_" + mesh["material"] + ".dae")
        root = ET.parse(path).getroot()
        assert int(root.find(".//c:triangles", ns).get("count")) == mesh["triangles"]


def test_all_servo_exteriors_follow_their_input_and_output_bodies():
    report = json.loads((MODEL / "conversion_report.json").read_text())
    restoration = report["servo_restoration"]
    assert not {"280", "283", "286", "290", "294"} & {p["model_id"] for p in report["retained_parts"]}
    assert {"motor", "PCB", "internal gear"} <= set(restoration["source"]["excluded"])
    instances = restoration["instances"]
    assert len(instances) == len({p["source_path"] for p in instances}) == 12
    for side in ("left", "right"):
        assert sorted(p["stage"] for p in instances if p["side"] == side) == list(range(1, 7))
    for servo in instances:
        stage, side = servo["stage"], servo["side"]
        expected_housing = "lift_carriage" if stage == 1 else f"{side}_arm_link{min(stage - 1, 5)}"
        expected_output = f"{side}_arm_link{min(stage, 5)}"
        pieces = {p["part"]: p for p in servo["parts"]}
        assert set(pieces) == {"upper_cover", "lower_cover", "277", "297", "300"}
        for name in ("upper_cover", "lower_cover", "277"):
            assert pieces[name]["link"] == expected_housing
        for name in ("297", "300"):
            assert pieces[name]["link"] == expected_output
        if stage <= 5:
            t = servo["cad_transform"]
            cad_axis = [t[i][3] - .0255 * t[i][0] for i in range(3)]
            ros_axis = [-cad_axis[0], cad_axis[2], cad_axis[1] + report["ground_offset_m"]]
            assert ros_axis == pytest.approx(report["rig"][expected_output]["origin"], abs=1e-9)
    source = restoration["source"]
    for filename, field in [("ST3215.step", "step_sha256"), ("servo_surfaces.npz", "surface_archive_sha256")]:
        assert hashlib.sha256((ROOT / "docs/model-source" / filename).read_bytes()).hexdigest() == source[field]
    assert source["registration"]["max_bounds_difference_mm"] < .002
    assert source["registration"]["max_native_vertex_to_vendor_surface_mm"] < .11
