#!/usr/bin/env python3
"""Measure the reserved lidar slot from the original active native CAD parts."""
import argparse
import json
from pathlib import Path
import numpy as np
import trimesh

parser=argparse.ArgumentParser()
parser.add_argument('--cad-analysis',type=Path,required=True)
parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'evidence/lidar-layer.json')
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
data=json.loads((root/'docs/chassis/measurements.json').read_text())
occurrences=json.loads((args.cad_analysis.parent/'assembly_summary.json').read_text())['occurrences']
transforms=json.loads((args.cad_analysis/'global_transforms.json').read_text())
rotation=np.array(data['cad_to_ros_rotation'])
shift=np.array([0,0,data['cad_ground_translation_m']])-data['cad_ros_base_origin_xyz_m']
parts={}
for mid,label in [('79','lower_decorative_shell'),('14','upper_plate'),('114','lidar_body')]:
    record=next(o for o in occurrences if o['model_id']==mid and not o['suppressed'] and not o['hidden'])
    mesh=trimesh.load(args.cad_analysis/'native_meshes'/f'{mid}.ply',process=False)
    t=np.array(transforms[record['path']])
    vertices=(mesh.vertices@t[:3,:3].T+t[:3,3])@rotation.T+shift
    parts[label]=dict(model_id=mid,name=record['display_name'],bounds_m=[vertices.min(0).tolist(),vertices.max(0).tolist()])
bottom=parts['lower_decorative_shell']['bounds_m'][1][2]
top=parts['upper_plate']['bounds_m'][0][2]
old=data['lidar']['nominal_scan_xyz_m'][2]
height=(bottom+top)/2
pillars=[]
for record in occurrences:
    if record['model_id']!='17' or record['suppressed'] or record['hidden']:
        continue
    mesh=trimesh.load(args.cad_analysis/'native_meshes/17.ply',process=False)
    t=np.array(transforms[record['path']])
    mesh.vertices=(mesh.vertices@t[:3,:3].T+t[:3,3])@rotation.T+shift
    section=mesh.section(plane_origin=[0,0,height],plane_normal=[0,0,1])
    paths=[path[:,:2].tolist() for path in section.discrete] if section is not None else []
    pillars.append(dict(name=record['path'],bounds_m=mesh.bounds.tolist(),section_xy_m=paths))
report=dict(source_archive_sha256=data['source_archive_sha256'],parts=parts,
            slot_bottom_m=bottom,slot_top_m=top,slot_clearance_m=top-bottom,
            old_scan_height_m=old,old_relative_to_shell_top_m=old-bottom,
            candidate_scan_height_m=height,pillars=pillars,
            status='CAD slot midpoint for simulation; actual optical plane is not calibrated')
args.output.parent.mkdir(parents=True,exist_ok=True)
args.output.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='parts'},indent=2))
