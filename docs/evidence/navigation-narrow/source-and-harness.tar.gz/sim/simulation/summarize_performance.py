#!/usr/bin/env python3
"""Summarize frozen navigation trials without changing acceptance thresholds."""
import argparse,csv,hashlib,json,math,statistics
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


def read(root):
    return [dict(json.loads(p.read_text()),record=str(p),trajectory=str(p.with_name('trajectory.csv'))) for p in sorted(Path(root).glob('*/result.json'))]


def main():
    p=argparse.ArgumentParser();p.add_argument('--primary',nargs='+',required=True);p.add_argument('--previous',required=True);p.add_argument('--paired',required=True);p.add_argument('--checks',required=True);p.add_argument('--output',required=True);args=p.parse_args()
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    primary=sum((read(r) for r in args.primary),[]);old=read(args.previous);paired=read(args.paired);checks=read(args.checks)
    keys=[(r['case'],r['seed']) for r in primary];assert len(keys)==len(set(keys)), 'Duplicate primary trials'
    for r in primary:
        assert r.get('verified_build'),r['record']
    data=dict(primary=primary,previous_paired=old,optimized_paired=paired,checks=checks,
        acceptance=dict(position_m=.020,yaw_rad=.035,terminal_speed_mps=.020,no_collision=True),
        primary_counts=dict(attempts=len(primary),action_arrivals=sum(r.get('success',False) for r in primary),
            strict_arrivals=sum(r.get('arrival_acceptance_pass',False) for r in primary),
            startup_errors=sum('error' in r for r in primary),collisions=sum(r.get('collision_events',0) for r in primary)))
    (out/'results.json').write_text(json.dumps(data,indent=2))
    fields=['case','seed','status','success','arrival_acceptance_pass','goal_position_error_m','goal_yaw_error_rad','final_speed_mps','sim_elapsed_s','speed_p95_mps','min_clearance_m','localization_p95_m','guard_compute_p95_ms','guard_compute_max_ms','controller_deadline_warnings','error']
    with (out/'results.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore',lineterminator='\n');w.writeheader();w.writerows(primary)
    rows=[]
    for case in sorted({r['case'] for r in primary}):
        group=[r for r in primary if r['case']==case]
        arrived=[r for r in group if r.get('arrival_acceptance_pass')]
        maximum=lambda records,key,scale=1:max((r[key]*scale for r in records if r.get(key) is not None),default=math.nan)
        times=[r['sim_elapsed_s'] for r in arrived]
        minimum_clearance=min((r['min_clearance_m']*1000 for r in group if r.get('min_clearance_m') is not None),default=math.nan)
        coverage=min((r['localization_samples']/r['truth_samples']*100 for r in group if r.get('truth_samples')),default=math.nan)
        rows.append(f"| {case} | {len(arrived)}/{len(group)} | {maximum(arrived,'goal_position_error_m',1000):.1f} | {maximum(arrived,'goal_yaw_error_rad',180/math.pi):.2f} | {statistics.median(times) if times else math.nan:.1f} | {maximum(group,'localization_p95_m',1000):.1f} | {minimum_clearance:.1f} | {coverage:.1f}% |")
    (out/'table.md').write_text('| 场景 | 严格到达 | 成功最大终点误差 mm | 成功最大角度误差 ° | 成功耗时中位数 s | 最大定位 P95 mm | 最小真值净距 mm | 最低 TF 配对覆盖率 |\n| --- | --- | --- | --- | --- | --- | --- | --- |\n'+'\n'.join(rows)+'\n')
    cases=sorted({r['case'] for r in paired});fig,axes=plt.subplots(1,3,figsize=(14,4.5))
    matched={(r['case'],r['seed']) for r in old if r.get('arrival_acceptance_pass')} & {(r['case'],r['seed']) for r in paired if r.get('arrival_acceptance_pass')}
    for group,label,color in [(old,'Previous upgrade','#999999'),(paired,'Optimized','#007f84')]:
        times=[statistics.median(values) if values else math.nan for c in cases
               for values in [[r['sim_elapsed_s'] for r in group if r['case']==c and (r['case'],r['seed']) in matched]]]
        x=np.arange(len(cases))+(0 if group is old else .38);axes[0].bar(x,times,width=.38,label=label,color=color)
    axes[0].set_xticks(np.arange(len(cases))+.19,cases,rotation=35,ha='right');axes[0].set_ylabel('Matched strict-pair median time (s)');axes[0].legend()
    for key,title,scale in [('goal_position_error_m','Actual goal position error (mm)',1000),('localization_p95_m','Per-trial localization P95 (mm)',1000)]:
        ax=axes[1 if key.startswith('goal') else 2];values=sorted(r[key]*scale for r in primary if r.get(key) is not None and r.get('success'))
        if values:ax.step(values,np.arange(1,len(values)+1)/len(values),where='post',color='#007f84')
        ax.set_xlabel(title);ax.set_ylabel('Fraction of arrived trials');ax.grid(alpha=.2)
        if key.startswith('goal'):ax.axvline(20,color='#ce582a',ls='--',label='20 mm acceptance');ax.legend()
    fig.tight_layout();fig.savefig(out/'performance.png',dpi=170);plt.close(fig)
    fig,axes=plt.subplots(2,3,figsize=(13,8),sharex=True,sharey=True)
    for seed,ax in zip(sorted({r['seed'] for r in primary}),axes.flat):
        r=next((r for r in primary if r['case']=='online_chicane' and r['seed']==seed),None)
        if not r:continue
        case=json.loads(Path(r['record']).with_name('case.json').read_text())
        for obstacle in case['obstacle_reference']:
            ax.add_patch(plt.Rectangle((obstacle['x']-obstacle['sx']/2,obstacle['y']-obstacle['sy']/2),obstacle['sx'],obstacle['sy'],color='#888888'))
        if not Path(r['trajectory']).exists():
            ax.set_title(f"Seed {seed}: {r.get('error', 'missing trajectory')}");continue
        with Path(r['trajectory']).open() as f:a=list(csv.DictReader(f))
        ax.plot([float(q['x']) for q in a],[float(q['y']) for q in a],color='#007f84',lw=2)
        ax.plot([float(q['estimated_x']) for q in a],[float(q['estimated_y']) for q in a],color='#ce582a',ls='--',lw=.8)
        ax.set_title(f"Seed {seed}: {r.get('goal_position_error_m',math.nan)*1000:.1f} mm; pass={r.get('arrival_acceptance_pass')}");ax.set_xlim(-2.3,2.3);ax.set_ylim(-1.7,1.7);ax.set_aspect('equal');ax.grid(alpha=.2)
    fig.suptitle('Unknown chicane: truth trajectory (teal), estimated pose (orange)');fig.tight_layout();fig.savefig(out/'online-chicane.png',dpi=170)
    print(json.dumps(data['primary_counts']))


if __name__=='__main__':main()
