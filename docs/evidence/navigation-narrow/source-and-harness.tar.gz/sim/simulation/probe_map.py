#!/usr/bin/env python3
"""Validate live SLAM output and preserve the actual occupancy grid."""
import json
import argparse
from pathlib import Path
import time
import numpy as np
import yaml
from PIL import Image
import rclpy
from rclpy.qos import QoSProfile, DurabilityPolicy
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import Twist
from validate_runtime import Probe, yaw

parser=argparse.ArgumentParser()
parser.add_argument('--drive-square',action='store_true',help='Drive only this isolated simulation in a 0.6 m square')
args=parser.parse_args()
rclpy.init()
node=Probe()
subscription=node.create_subscription(OccupancyGrid,'/map',lambda msg:node.receive('map',msg),
    QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL))
node.wait(lambda:'map' in node.latest and 'odom' in node.tf and 'scan' in node.latest)
path=[]
if args.drive_square:
    node.wait(lambda:'clock' in node.latest and 'odom' in node.latest)
    try:
        for name,vx,vy in [('forward',.1,0),('left',0,.1),('back',-.1,0),('right',0,-.1)]:
            cmd=Twist();cmd.linear.x=float(vx);cmd.linear.y=float(vy)
            node.advance(6,cmd);node.advance(1,Twist())
            pose=node.latest['odom'].pose.pose.position
            path.append(dict(segment=name,x=pose.x,y=pose.y))
            print(json.dumps(path[-1]),flush=True)
    finally:
        node.cmd.publish(Twist())
    node.advance(4,Twist())
grid=node.latest['map']
data=np.array(grid.data,dtype=np.int16).reshape(grid.info.height,grid.info.width)
assert grid.header.frame_id=='map' and grid.info.resolution>0
assert (data>=65).sum()>100 and (data==0).sum()>1000, (int((data>=65).sum()),int((data==0).sum()))
assert node.tf['odom'].header.frame_id=='map'
pixels=np.full(data.shape,205,dtype=np.uint8)
pixels[data==0]=254
pixels[data>=65]=0
Image.fromarray(np.flipud(pixels)).save('/tmp/slam-map.pgm')
Path('/tmp/slam-map.yaml').write_text(yaml.safe_dump(dict(image='slam-map.pgm',mode='trinary',
    resolution=float(grid.info.resolution),origin=[grid.info.origin.position.x,grid.info.origin.position.y,
    yaw(grid.info.origin.orientation)],negate=0,occupied_thresh=.65,free_thresh=.25)))
report=dict(status='passed',frame=grid.header.frame_id,resolution_m=grid.info.resolution,
            width=grid.info.width,height=grid.info.height,occupied_cells=int((data>=65).sum()),
            free_cells=int((data==0).sum()),unknown_cells=int((data<0).sum()),
            origin_xyz=[grid.info.origin.position.x,grid.info.origin.position.y,grid.info.origin.position.z],
            tf_chain=['map','odom','base_footprint','base_link','lidar_link','laser'],
            driven_path=path,
            validation_scope='Live SLAM occupancy grid and TF; no Nav2 path-following test')
Path('/tmp/map-validation.json').write_text(json.dumps(report,indent=2))
Image.fromarray(np.flipud(pixels)).resize((grid.info.width*3,grid.info.height*3),Image.NEAREST).save('/tmp/slam-map.png')
print(json.dumps(report,indent=2))
node.destroy_node();rclpy.shutdown()
