#!/usr/bin/env bash
# 36 regression + 36 new-seed validation trials; uses the actual hardware sources.
set -euo pipefail
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$script_dir/navigation_benchmark.sh" --variants upgraded --seeds 1 2 3 14 15 16 \
  --cases open corridor_0.50 thin_obstacles s_bend dynamic_crossing sensor_dropout \
    initial_pose_error online_thin online_open office_chicane online_chicane reverse_goal "$@"
