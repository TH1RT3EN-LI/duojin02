set -eo pipefail; source /opt/ros/humble/setup.bash; source /candidate/.cache/slam-install/setup.bash; source /candidate/.cache/tuned-gpu/install/local_setup.bash; exec "$1" "$2" 80 "$3" "$4"
