#!/usr/bin/env bash
set -euo pipefail
sim_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
hardware_root="${DUOJIN_HARDWARE_SOURCE:-$(dirname "$sim_root")/duojin02}"
output="${DUOJIN_NAV_OUTPUT:-$sim_root/simulation/results/navigation}"
mkdir -p "$output"
exec docker run --rm --init --gpus all --shm-size=1g \
  --name "${DUOJIN_NAV_CONTAINER:-duojin02-navigation-benchmark}" \
  -e NVIDIA_DRIVER_CAPABILITIES=graphics,display,utility,compute \
  -e "ROS_DOMAIN_ID=${DUOJIN_SIM_DOMAIN:-79}" -e "GZ_PARTITION=${DUOJIN_SIM_PARTITION:-duojin02_nav_test}" \
  -v "$hardware_root:/hardware:ro" -v "$sim_root:/ws:ro" -v "$output:/evidence" \
  --entrypoint bash "${DUOJIN_SIM_IMAGE:-duojin02:sim-humble-harmonic}" /ws/simulation/benchmark_entry.sh "$@"
