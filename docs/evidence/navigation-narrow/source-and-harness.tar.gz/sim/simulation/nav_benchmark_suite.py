#!/usr/bin/env python3
"""Sequential, isolated paired trials. Never reuse a surviving ROS graph."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--cases',nargs='+',default=['open','corridor_0.56','corridor_0.50','corridor_0.46',
        'corridor_0.44','corridor_0.40','thin_obstacles','s_bend','dynamic_crossing','sensor_dropout','initial_pose_error','online_thin'])
    parser.add_argument('--seeds',nargs='+',type=int,default=[1])
    parser.add_argument('--variants',nargs='+',default=['baseline','upgraded'])
    parser.add_argument('--nav-config',default='')
    parser.add_argument('--output',default='/evidence/final')
    args=parser.parse_args();output=Path(args.output);output.mkdir(parents=True,exist_ok=True)
    results=[]
    for seed in args.seeds:
        for case in args.cases:
            for variant in args.variants:
                directory=output/f'{case}-{variant}-{seed}'
                subprocess.run([sys.executable,str(Path(__file__).with_name('nav_benchmark.py')),
                    '--case',case,'--variant',variant,'--seed',str(seed),'--output',str(directory),'--nav-config',args.nav_config],check=True)
                results.append(json.loads((directory/'result.json').read_text()))
                (output/f'suite-{os.environ.get("ROS_DOMAIN_ID","default")}.json').write_text(json.dumps(results,indent=2))


if __name__=='__main__':main()
