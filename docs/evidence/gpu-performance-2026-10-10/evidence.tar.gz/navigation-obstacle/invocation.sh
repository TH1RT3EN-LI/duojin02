set -eo pipefail
arm="$1";seed="$2";output="$3"
root=/candidate;config=/candidate/src/duojin01_bringup/config/nav2.yaml
if [ "$arm" = original ];then root=/original;config=/original/src/duojin01_bringup/config/nav2.yaml;fi
if [ "$arm" = gpu ];then config=/candidate/.cache/profiles/gpu.yaml;fi
ln -sfn "$root" /hardware;ln -sfn "/candidate/.cache/full-$arm" /tmp/navbuild
source /opt/ros/humble/setup.bash;source /candidate/.cache/slam-install/setup.bash;source "/candidate/.cache/full-$arm/install/local_setup.bash"
export GZ_SIM_SYSTEM_PLUGIN_PATH=/tmp/duojin02_odometry_plugin
export GZ_PARTITION="duojin_gpu_obstacle_${arm}_${seed}_$$";export QT_QPA_PLATFORM=offscreen
python3 /candidate/tests/performance/navigation_harness/record_build.py
exec python3 /candidate/tests/performance/navigation_harness/nav_benchmark.py --case offplan_obstacle --variant upgraded --seed "$seed" --nav-config "$config" --scenario-file /evidence/navigation-obstacle/fixture.json --output "$output"
