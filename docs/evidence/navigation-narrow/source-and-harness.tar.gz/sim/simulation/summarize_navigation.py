#!/usr/bin/env python3
"""Produce auditable tables and trajectory plots from completed trials."""
import argparse
import csv
import json
import math
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Polygon


def main():
    parser=argparse.ArgumentParser();parser.add_argument('root');parser.add_argument('--output',required=True)
    args=parser.parse_args();root=Path(args.root);output=Path(args.output);output.mkdir(parents=True,exist_ok=True)
    reports=[dict(json.loads(p.read_text()),artifact_directory=p.parent.name) for p in sorted(root.glob('*/result.json'))]
    for report in reports:
        trajectory=root/report['artifact_directory']/'trajectory.csv'
        report['near_contact_threshold_m']=.002
        report['near_contact_events']=None
        report['localization_tf_coverage']=report.get('localization_samples',0)/max(1,report.get('truth_samples',0))
        if trajectory.exists():
            with trajectory.open() as stream:
                rows=list(csv.DictReader(stream))
                flags=[float(row['clearance'])<=.002 for row in rows]
            report['near_contact_events']=sum(value and (i==0 or not flags[i-1]) for i,value in enumerate(flags))
            report['final_truth_speed_mps']=float(rows[-1]['speed']) if rows else None
    (output/'results.json').write_text(json.dumps(reports,indent=2))
    columns=['case','variant','seed','expected_outcome','success','safety_stop_pass','collision_events','near_contact_events','aperture_crossed','min_clearance_m',
        'localization_rmse_m','localization_p95_m','localization_yaw_rmse_rad','goal_position_error_m',
        'goal_yaw_error_rad','path_length_m','sim_elapsed_s','command_period_p95_ms','guard_compute_p95_ms',
        'scan_dropout_stop_latency_s','controller_deadline_warnings','localization_tf_coverage','final_truth_speed_mps','error']
    with (output/'results.csv').open('w') as stream:
        writer=csv.DictWriter(stream,fieldnames=columns,extrasaction='ignore');writer.writeheader();writer.writerows(reports)
    fmt=lambda value,scale=1: '—' if value is None else f'{value*scale:.1f}'
    lines=['| 场景 | 配置/种子 | 到达 | 碰撞 | 最小间距 mm | 定位 RMSE/P95 mm | 目标误差 mm/° | 耗时 s |',
           '|---|---|---:|---:|---:|---:|---:|---:|']
    for r in reports:
        outcome=('安全停车' if r.get('safety_stop_pass') else '停车失败') if r.get('expected_outcome')=='safe_stop' else ('是' if r.get('success') else '否')
        lines.append(f"| {r['case']} | {r['variant']}/{r['seed']} | {outcome} | {r.get('collision_events','—')} | "+
            f"{fmt(r.get('min_clearance_m'),1000)} | {fmt(r.get('localization_rmse_m'),1000)}/{fmt(r.get('localization_p95_m'),1000)} | "+
            f"{fmt(r.get('goal_position_error_m'),1000)}/{fmt(r.get('goal_yaw_error_rad'),180/math.pi)} | {fmt(r.get('sim_elapsed_s'))} |")
    (output/'results-table.md').write_text('\n'.join(lines)+'\n')
    chosen=['open','corridor_0.50','corridor_0.46','thin_obstacles','s_bend','dynamic_crossing','sensor_dropout','initial_pose_error','online_thin']
    fig,axes=plt.subplots(3,3,figsize=(14,10),constrained_layout=True)
    footprint=np.array([[.213,.191465],[.201465,.203],[-.202879,.203],[-.214,.191879],[-.214,-.190465],[-.201465,-.203],[.202879,-.203],[.213,-.192879]])
    for ax,name in zip(axes.flat,chosen):
        entries=[r for r in reports if r['case']==name and r['seed']==1]
        reference=next((root/r['artifact_directory']/'case.json' for r in entries if (root/r['artifact_directory']/'case.json').exists()),None)
        if reference:
            case=json.loads(reference.read_text())
            for o in case['obstacle_reference']:
                ax.add_patch(Rectangle((o['x']-o['sx']/2,o['y']-o['sy']/2),o['sx'],o['sy'],color='.8'))
            ax.plot(*case['goal'][:2],'k*',markersize=8)
        for r in entries:
            path=root/r['artifact_directory']/'trajectory.csv'
            if not path.exists():continue
            d=np.genfromtxt(path,delimiter=',',names=True);color='#1671bd' if r['variant']=='baseline' else '#d45b12'
            stimulus=root/r['artifact_directory']/'stimuli.json'
            if stimulus.exists():
                for o in json.loads(stimulus.read_text()):
                    ax.add_patch(Rectangle((o['x']-o['sx']/2,o['y']-o['sy']/2),o['sx'],o['sy'],facecolor=color,alpha=.2))
            ax.plot(d['x'],d['y'],color=color,label=r['variant'])
            index=int(np.argmin(d['clearance']));yaw=d['yaw'][index]
            rotation=np.array([[math.cos(yaw),-math.sin(yaw)],[math.sin(yaw),math.cos(yaw)]])
            ax.add_patch(Polygon(footprint@rotation.T+[d['x'][index],d['y'][index]],fill=False,edgecolor=color,linewidth=1))
        ax.set_title(name);ax.set_aspect('equal');ax.set_xlim(-2.1,2.1);ax.set_ylim(-1,1);ax.grid(alpha=.2)
    axes.flat[0].legend();fig.savefig(output/'trajectories.png',dpi=160);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(10,4),constrained_layout=True)
    for variant,color in [('baseline','#1671bd'),('upgraded','#d45b12')]:
        open_trials=[r for r in reports if r['case']=='open' and r['variant']==variant]
        errors=[]
        for r in open_trials:
            path=root/r['artifact_directory']/'trajectory.csv'
            if not path.exists():continue
            d=np.genfromtxt(path,delimiter=',',names=True)
            e=np.hypot(d['estimated_x']-d['x'],d['estimated_y']-d['y']);errors.extend(e[np.isfinite(e)]*1000)
        if errors:
            values=np.sort(errors);axes[0].plot(values,np.arange(1,len(values)+1)/len(values),label=variant,color=color)
        widths=sorted({float(r['case'].split('_')[1]) for r in reports if r['case'].startswith('corridor_')})
        rates=[]
        for width in widths:
            trials=[r for r in reports if r['case']==f'corridor_{width:.2f}' and r['variant']==variant]
            rates.append(sum(bool(r.get('success')) and bool(r.get('aperture_crossed')) for r in trials)/len(trials) if trials else 0)
        axes[1].plot(np.array(widths)*100,rates,'o-',label=variant,color=color)
    axes[0].set_xlabel('Open scenario position error (mm)');axes[0].set_ylabel('Empirical CDF');axes[0].set_xlim(0,100)
    axes[1].set_xlabel('Forced aperture width (cm)');axes[1].set_ylabel('Observed traversal success fraction');axes[1].set_ylim(-.05,1.05)
    for ax in axes:ax.grid(alpha=.2);ax.legend()
    fig.savefig(output/'accuracy-and-clearance.png',dpi=160);plt.close(fig)


if __name__=='__main__':main()
