#!/usr/bin/env python3
"""Compare recorded raw lidar with exact native CAD pillar sections."""
import argparse
import json
import math
from pathlib import Path
import numpy as np


def intersections(paths, origin, angles):
    directions = np.column_stack((np.cos(angles), np.sin(angles)))
    distances = np.full(len(angles), np.inf)
    for path in paths:
        for a, b in zip(np.array(path)[:-1], np.array(path)[1:]):
            edge, delta = b-a, a-origin
            den = directions[:, 0]*edge[1]-directions[:, 1]*edge[0]
            valid = np.abs(den) > 1e-12
            t = np.full(len(angles), np.inf)
            u = np.full(len(angles), np.inf)
            t[valid] = (delta[0]*edge[1]-delta[1]*edge[0])/den[valid]
            u[valid] = (delta[0]*directions[valid, 1]-delta[1]*directions[valid, 0])/den[valid]
            hit = valid & (t > 0) & (u >= 0) & (u <= 1)
            distances[hit] = np.minimum(distances[hit], t[hit])
    return distances


def validate(folder, layer_file):
    scan = json.loads((folder/'scan_snapshot.json').read_text())
    layer = json.loads(layer_file.read_text())
    c, s = math.cos(scan['yaw']), math.sin(scan['yaw'])
    origin = (np.array(scan['laser_world_xy'])-scan['base_world_xy']) @ np.array([[c,-s],[s,c]])
    angles = scan['angle_min']+np.arange(len(scan['ranges']))*scan['angle_increment']
    raw = np.array([np.nan if v is None else v for v in scan['raw_ranges']])
    filtered = np.array([np.nan if v is None else v for v in scan['ranges']])
    report = dict(status='passed', scan_height_m=layer['candidate_scan_height_m'],
                  source_archive_sha256=layer['source_archive_sha256'], pillars=[])
    for index, pillar in enumerate(layer['pillars'], 1):
        expected = intersections(pillar['section_xy_m'], origin, angles)
        bins = np.flatnonzero(np.isfinite(expected))
        error = np.abs(raw[bins]-expected[bins])
        matched = np.isfinite(error) & (error < 0.008)
        midpoint = bins[len(bins)//2]
        result = dict(pillar=index, predicted_blocked_bins=bins.tolist(),
                      matched_bins=int(matched.sum()), maximum_error_m=float(np.nanmax(error)),
                      middle_bin=int(midpoint), middle_range_m=float(raw[midpoint]),
                      middle_expected_m=float(expected[midpoint]),
                      public_output_all_invalid=bool(np.isnan(filtered[bins]).all()))
        report['pillars'].append(result)
        assert len(bins)>0 and matched.all(), result
        assert result['public_output_all_invalid'], result
    assert len(report['pillars']) == 6
    report['total_pillar_blocked_bins'] = sum(len(p['predicted_blocked_bins']) for p in report['pillars'])
    report['total_filtered_bins'] = int((np.isfinite(raw)&np.isnan(filtered)).sum())
    (folder/'pillar-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('folder',type=Path)
    parser.add_argument('--layer',type=Path,default=Path(__file__).resolve().parent/'evidence/lidar-layer.json')
    args = parser.parse_args()
    print(json.dumps(validate(args.folder,args.layer),indent=2))
