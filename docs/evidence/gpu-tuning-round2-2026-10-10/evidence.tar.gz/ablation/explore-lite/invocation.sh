set -eo pipefail
root="$1";build="$2";manifest="$3";config="$4";case_name="$5";seed="$6";output="$7";fixture="$8"
ln -sfn "$root" /hardware
ln -sfn "$manifest" /tmp/navbuild
source /opt/ros/humble/setup.bash
source /candidate/.cache/slam-install/setup.bash
source "$build/install/local_setup.bash"
export GZ_SIM_SYSTEM_PLUGIN_PATH=/tmp/duojin02_odometry_plugin
export GZ_PARTITION="duojin_tuning_${case_name}_${seed}_$$"
export QT_QPA_PLATFORM=offscreen
test -f /tmp/navbuild/navigation-build.json
extra=()
if [ "$fixture" != - ];then extra+=(--scenario-file "$fixture");fi
exec timeout --signal=INT --kill-after=15s 180s python3 /candidate/tests/performance/navigation_harness/nav_benchmark.py --variant upgraded \
 --case "$case_name" --seed "$seed" --nav-config "$config" --output "$output" "${extra[@]}"
